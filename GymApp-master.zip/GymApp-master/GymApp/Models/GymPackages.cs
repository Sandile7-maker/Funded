﻿
using System.ComponentModel.DataAnnotations;

namespace GymApp.Models
{
    public class GymPackages
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required]
        public int DurationInDays { get; set; } // How many days the package lasts
    }
}