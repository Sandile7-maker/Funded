﻿namespace GymApp.Models
{
    public class Subscription
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public int GymPackageId { get; set; }
        public DateTime StartDate { get; set; } = DateTime.UtcNow;
        public DateTime EndDate { get; set; }

        public byte[] QrCodeData { get; set; }

        // Navigation
        public User User { get; set; }
        public GymPackages GymPackage { get; set; }
    }
}
