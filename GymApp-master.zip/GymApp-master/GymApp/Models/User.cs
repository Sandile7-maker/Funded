﻿using Microsoft.AspNetCore.Identity;

namespace GymApp.Models
{
    public class User : IdentityUser
    {
        public string FullName { get; set; }

    }
}
