﻿namespace GymApp.Models
{
    public class MembershipFreezeRequest
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public DateTime RequestedOn { get; set; }
        public int DaysRequested { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}
