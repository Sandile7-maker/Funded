﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymApp.Models
{
    public class Workout
    {
        public int Id { get; set; }

        [Required, MaxLength(150)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Instructions { get; set; }

        [Required]
        [Range(10, 3600, ErrorMessage = "Duration must be between 10 seconds and 1 hour.")]
        public int DurationInSeconds { get; set; }

        [Url]
        public string? GifUrl { get; set; }

        // 🔗 Relationship with GymPackage
        [ForeignKey("GymPackage")]
        public int PackageId { get; set; }
        public GymPackages GymPackage { get; set; } = null!;
    }
}
