﻿namespace GymApp.Models
{
    public class CheckoutSession
    {
        public string SessionId { get; set; }
        public string ClientSecret { get; set; }
    }
}