﻿namespace GymApp.Models.ViewModels.Gymbuddy
{
    public class WorkoutListingViewModel
    {
        public int SubscriptionId { get; set; }
        public string PackageName { get; set; }
        public List<WorkoutViewModel> Workouts { get; set; } = new();
    }

    public class WorkoutViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string GifUrl { get; set; }
        public string Instructions { get; set; }
        public int DurationInSeconds { get; set; }
    }
}
