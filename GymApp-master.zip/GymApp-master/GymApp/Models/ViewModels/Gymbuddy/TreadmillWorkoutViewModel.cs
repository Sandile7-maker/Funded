﻿namespace GymApp.Models.ViewModels.Gymbuddy
{
    
        public class TreadmillWorkoutViewModel
        {
        public double SpeedKmh { get; set; }
        public double WeightKg { get; set; }

        // Live stats
        public double TimeMinutes { get; set; }
        public double DistanceKm { get; set; }
        public double Calories { get; set; }
    }

}
