﻿namespace GymApp.Models.ViewModels
{
    public class FreezeRequestViewModel
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string UserFullName { get; set; } = string.Empty;
        public DateTime RequestedOn { get; set; }
        public int DaysRequested { get; set; }
        public string Status { get; set; } = string.Empty;
    }

}
