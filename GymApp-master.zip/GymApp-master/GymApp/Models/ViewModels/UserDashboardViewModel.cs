﻿using GymApp.Models;

namespace GymApp.Models.ViewModels
{
    public class UserDashboardViewModel
    {
        public List<MembershipFreezeRequest> FreezeRequests { get; set; }
        public string FullName { get; set; }
        public List<Subscription> Subscriptions { get; set; } = new();
    }
    public class UserSubscriptionViewModel
    {
        public int Id { get; set; }
        public Subscription Subscription { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public byte[]? QrCodeData { get; set; }
    }
}
