﻿namespace GymApp.Models.ViewModels
{
    public class TrainerDashboardViewModel
    {
        public IEnumerable<Trainer> Trainers { get; set; } = new List<Trainer>();

        public TrainerAssignmentRequest? CurrentRequest { get; set; }

        public Trainer? AssignedTrainer { get; set; }
    }
}
