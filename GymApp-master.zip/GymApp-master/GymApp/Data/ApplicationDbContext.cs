﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using GymApp.Models;
using Microsoft.EntityFrameworkCore;

namespace GymApp.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {  
        }
        public DbSet<GymPackages> GymPackages { get; set; }
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<Workout> Workouts  { get; set; }
        public DbSet<MembershipFreezeRequest> MembershipFreezeRequests { get; set; }
        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<TrainerAssignmentRequest> TrainerAssignmentRequests { get; set; }

    }
}
