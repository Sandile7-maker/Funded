﻿using GymApp.Migrations;
using GymApp.Models;
using Microsoft.AspNetCore.Identity;

namespace GymApp.Data
{
    public static class DbSeeder
    {
        public static async Task SeedRolesAndAdminAsync(
            UserManager<User> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            // Define roles
            string[] roles = { "Admin", "Trainer", "Member", "Scanner" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            // Create admin user if not exists
            var adminEmail = "admin@gymapp.com";
            var scannerEmail = "scanner1@gymapp.com"; // lowercase for consistency

            var adminUser = await userManager.FindByEmailAsync(adminEmail);
            var scannerUser = await userManager.FindByEmailAsync(scannerEmail);

            if (adminUser == null)
            {
                adminUser = new User
                {
                    FullName = "Administrator",
                    UserName = "admin",
                    Email = adminEmail,
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(adminUser, "Admin@123");

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }

            if (scannerUser == null)
            {
                scannerUser = new User
                {
                    FullName = "Scanner",
                    UserName = "scanner1",
                    Email = scannerEmail,
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(scannerUser, "Scanner@123");

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(scannerUser, "Scanner");
                }
            }
        }

        public static async Task SeedGymPackagesAsync(ApplicationDbContext context)
        {
            if (!context.GymPackages.Any())
            {
                var packages = new List<GymPackages>
                {
                    new GymPackages
                    {
                        Name = "Basic Package",
                        Price = 299.99m,
                        Description = "Access to gym equipment and locker rooms.",
                        DurationInDays = 30
                    },
                    new GymPackages
                    {
                        Name = "Standard Package",
                        Price = 499.99m,
                        Description = "Includes Basic Package + 4 personal training sessions.",
                        DurationInDays = 30
                    },
                    new GymPackages
                    {
                        Name = "Premium Package",
                        Price = 899.99m,
                        Description = "Includes Standard Package + unlimited classes and spa access.",
                        DurationInDays = 30
                    }
                };

                await context.GymPackages.AddRangeAsync(packages);
                await context.SaveChangesAsync();
            }
        }

        public static async Task SeedWorkoutsAsync(ApplicationDbContext context)
        {
            if (!context.Workouts.Any())
            {
                var workouts = new List<Workout>
                {
                    new Workout
                    {
                        Title = "Jumping Jacks",
                        Instructions = "Perform jumping jacks for 30 seconds, keeping a steady pace.",
                        DurationInSeconds = 30,
                        GifUrl = "~/Videos/Workouts/jumping-jacks.mp4",
                        PackageId = 2 
                    },
                    new Workout
                    {
                        Title = "Push-Ups",
                        Instructions = "Keep your back straight, lower until elbows are at 90°, then push back up.",
                        DurationInSeconds = 45,
                        GifUrl = "~/Videos/Workouts/jumping-jacks.mp4",
                        PackageId = 1
                    },
                    new Workout
                    {
                        Title = "Plank",
                        Instructions = "Hold a plank position with core tight and back straight.",
                        DurationInSeconds = 60,
                        GifUrl = "~/Videos/Workouts/Plank.mp4",
                        PackageId = 2
                    },
                    new Workout
                    {
                        Title = "Squats",
                        Instructions = "Stand with feet shoulder-width apart, lower hips down, then return up.",
                        DurationInSeconds = 40,
                        GifUrl = "~/Videos/Workouts/jumping-jacks.mp4",
                        PackageId = 1
                    }
                };

                await context.Workouts.AddRangeAsync(workouts);
                await context.SaveChangesAsync();
            }
        }

        public static async Task SeedTrainersAsync(ApplicationDbContext context)
        {
            if (!context.Trainers.Any())
            {
                var trainers = new List<Trainer>
        {
            new Trainer
            {
                FullName = "Vukani Buthelezi",
                Specialty = "Strength Training",
                Bio = "Vukani has 10 years of experience helping clients build muscle and strength.",
                Email = "Vukani.smith@gymapp.com",
                PhoneNumber = "0812345678"
            },
            new Trainer
            {
                FullName = "Philasande Gwaza",
                Specialty = "Yoga & Flexibility",
                Bio = "Phila specializes in yoga and improving flexibility for all fitness levels.",
                Email = "Phila.Gwaza@gymapp.com",
                PhoneNumber = "0823456789"
            },
            new Trainer
            {
                FullName = "Bongani Dlomo",
                Specialty = "Cardio & Endurance",
                Bio = "Bongani focuses on cardio training and endurance programs for optimal health.",
                Email = "Bongani.Dlomo@gymapp.com",
                PhoneNumber = "0834567890"
            }
        };

                await context.Trainers.AddRangeAsync(trainers);
                await context.SaveChangesAsync();
            }
        }
    }
}
