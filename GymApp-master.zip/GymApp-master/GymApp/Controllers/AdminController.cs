﻿using GymApp.Data;
using GymApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GymApp.Controllers
{
    [Authorize(Roles = "Admin,Scanner")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }


        public IActionResult Index()
        {
            var totalUsers = _context.Users.Count();
            var totalPackages = _context.GymPackages.Count();
            var pendingFreezes = _context.MembershipFreezeRequests.Count(r => r.Status == "Pending");
            var PendingTrainerRequests = _context.TrainerAssignmentRequests.Count(r => r.Status == "Pending");

            ViewBag.TotalUsers = totalUsers;
            ViewBag.TotalPackages = totalPackages;
            ViewBag.PendingFreezes = pendingFreezes;
            ViewBag.PendingTrainerRequests = PendingTrainerRequests;

            return View();
        }



        public IActionResult Scanner()
        {
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> VerifyQr(string qrContent)
        {
            try
            {
                if (string.IsNullOrEmpty(qrContent))
                    return Json(new { success = false, message = "No QR code provided." });

                var parts = qrContent.Split('|');
                if (parts.Length < 3)
                    return Json(new { success = false, message = "Invalid QR code format." });

                var userId = parts[0];
                if (!int.TryParse(parts[1], out int packageId))
                    return Json(new { success = false, message = "Invalid package ID." });

                var subscription = await _context.Subscriptions
                    .Include(s => s.User)
                    .Include(s => s.GymPackage)
                    .FirstOrDefaultAsync(s => s.UserId == userId && s.GymPackageId == packageId);

                if (subscription == null)
                    return Json(new { success = false, message = "Subscription not found." });

                var now = DateTime.UtcNow;
                if (subscription.StartDate <= now && subscription.EndDate >= now)
                {
                    return Json(new
                    {
                        success = true,
                        message = "Access allowed",
                        userName = subscription.User.FullName,
                        packageName = subscription.GymPackage.Name,
                        accessEnd = subscription.EndDate.ToString("yyyy-MM-dd")
                    });
                }
                else
                {
                    return Json(new { success = false, message = "Subscription expired." });
                }
            }
            catch (Exception ex)
            {
                // Always return JSON even on error
                return Json(new { success = false, message = "Server error: " + ex.Message });
            }





        }



        public async Task<IActionResult> FreezeRequests()
        {
            var requests = await _context.MembershipFreezeRequests.ToListAsync();

            var userIds = requests.Select(r => r.UserId).Distinct().ToList();
            var users = await _context.Users
                .Where(u => userIds.Contains(u.Id))
                .ToDictionaryAsync(u => u.Id, u => u.FullName);

            var model = requests.Select(r => new FreezeRequestViewModel
            {
                Id = r.Id,
                UserId = r.UserId,
                UserFullName = users.ContainsKey(r.UserId) ? users[r.UserId] : "Unknown",
                RequestedOn = r.RequestedOn,
                DaysRequested = r.DaysRequested,
                Status = r.Status
            }).ToList();

            return View(model);
        }




        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApproveFreeze(int id)
        {
            var request = await _context.MembershipFreezeRequests.FindAsync(id);
            if (request != null)
            {
                request.Status = "Approved";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("FreezeRequests");
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeclineFreeze(int id)
        {
            var request = await _context.MembershipFreezeRequests.FindAsync(id);
            if (request != null)
            {
                request.Status = "Declined";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("FreezeRequests");
        }
    }
}
