﻿using GymApp.Data;
using GymApp.Models;
using GymApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

[Authorize]
public class TrainersController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<User> _userManager;

    public TrainersController(ApplicationDbContext context, UserManager<User> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // List all trainers
    public async Task<IActionResult> Index()
    {
        var userId = _userManager.GetUserId(User);

        // Fetch all trainers
        var trainers = await _context.Trainers.ToListAsync();

        // Get the current request (if any)
        var currentRequest = await _context.TrainerAssignmentRequests
            .Include(r => r.Trainer)
            .FirstOrDefaultAsync(r => r.UserId == userId && r.Status != "Declined");

        Trainer? assignedTrainer = null;
        if (currentRequest != null && currentRequest.Status == "Approved")
        {
            assignedTrainer = currentRequest.Trainer;
            trainers = new List<Trainer> { assignedTrainer }; // Show only assigned trainer
        }

        var model = new TrainerDashboardViewModel
        {
            Trainers = trainers,
            CurrentRequest = currentRequest,
            AssignedTrainer = assignedTrainer
        };

        return View(model);
    }



    // User requests assignment to a trainer
    [HttpPost]
    public async Task<IActionResult> RequestTrainer(int trainerId)
    {
        var userId = _userManager.GetUserId(User);

        // Check if the user already has a pending request
        var existingRequest = await _context.TrainerAssignmentRequests
            .FirstOrDefaultAsync(r => r.UserId == userId && r.Status == "Pending");

        if (existingRequest != null)
        {
            TempData["Error"] = "You already have a pending trainer assignment request.";
            return RedirectToAction("Index");
        }

        var request = new TrainerAssignmentRequest
        {
            TrainerId = trainerId,
            UserId = userId,
            RequestedOn = DateTime.UtcNow,
            Status = "Pending"
        };

        _context.TrainerAssignmentRequests.Add(request);
        await _context.SaveChangesAsync();

        TempData["Message"] = "Your trainer assignment request has been submitted.";
        return RedirectToAction("Index");
    }








    // Admin: view all trainer requests
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AssignmentRequests()
    {
        var requests = await _context.TrainerAssignmentRequests
            .Include(r => r.Trainer)
            .Include(r => r.User)
            .ToListAsync();

        return View(requests);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ApproveRequest(int id)
    {
        var request = await _context.TrainerAssignmentRequests.FindAsync(id);
        if (request != null)
        {
            request.Status = "Approved";
            await _context.SaveChangesAsync();
        }
        return RedirectToAction("AssignmentRequests");
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeclineRequest(int id)
    {
        var request = await _context.TrainerAssignmentRequests.FindAsync(id);
        if (request != null)
        {
            request.Status = "Declined";
            await _context.SaveChangesAsync();
        }
        return RedirectToAction("AssignmentRequests");
    }
}
