﻿using GymApp.Data;
using GymApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QRCoder;
using Stripe;
using Stripe.Checkout;
using System.Drawing;
using System.Drawing.Imaging;
using System.Security.Claims;


namespace GymApp.Controllers
{
    [Authorize]
    public class GymPackagesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<User> _userManager;

        public GymPackagesController(ApplicationDbContext context, UserManager<User> userManager)
        {
            _userManager = userManager;
            _context = context;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);

            //dont allow admin
            if (await _userManager.IsInRoleAsync(user, "Admin"))
            {
                return RedirectToAction("Index", "Admin");
            }
            // Check Active subscriptions
            var hasSubscriptions = await _context.Subscriptions
                .AnyAsync(s => s.UserId == userId);

            if (!hasSubscriptions)
            {
               
                var packages = await _context.GymPackages.ToListAsync();
                return View("Index", packages);
            }

            // User has subscriptions, redirect to dashboard or another page
            return RedirectToAction("Index", "GymBuddy");
        }

        // GET: /GymPackages/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var package = await _context.GymPackages.FirstOrDefaultAsync(p => p.Id == id);
            if (package == null) return NotFound();

            return View(package);
        }

        // ===== Admin CRUD Operations =====
        [Authorize(Roles = "Admin")]
        // GET: /GymPackages/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(GymPackages package)
        {
            if (ModelState.IsValid)
            {
                _context.GymPackages.Add(package);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(package);
        }

        [Authorize(Roles = "Admin")]
        // GET: /GymPackages/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var package = await _context.GymPackages.FindAsync(id);
            if (package == null) return NotFound();
            return View(package);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, GymPackages package)
        {
            if (id != package.Id) return BadRequest();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(package);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.GymPackages.Any(p => p.Id == id)) return NotFound();
                    throw;
                }
            }
            return View(package);
        }

        [Authorize(Roles = "Admin")]
        // GET: /GymPackages/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var package = await _context.GymPackages.FindAsync(id);
            if (package == null) return NotFound();
            return View(package);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var package = await _context.GymPackages.FindAsync(id);
            if (package != null)
            {
                _context.GymPackages.Remove(package);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Subscribe(int id)
        {
            var package = await _context.GymPackages.FindAsync(id);
            if (package == null) return NotFound();

            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string> { "card" },
                LineItems = new List<SessionLineItemOptions>
        {
            new SessionLineItemOptions
            {
                PriceData = new SessionLineItemPriceDataOptions
                {
                    Currency = "zar",
                    ProductData = new SessionLineItemPriceDataProductDataOptions
                    {
                        Name = package.Name,
                    },
                    UnitAmount = (long)(package.Price * 100), // Convert Rands → cents
                },
                Quantity = 1,
            }
        },
                Mode = "payment",
                SuccessUrl = Url.Action("PaymentSuccess", "GymPackages", new { id = package.Id }, Request.Scheme),
                CancelUrl = Url.Action("PaymentCancel", "GymPackages", new { id = package.Id }, Request.Scheme),
            };

            var service = new SessionService();
            Session session = await service.CreateAsync(options);

            return Redirect(session.Url);
        }



        public async Task<IActionResult> PaymentSuccess(int id)
        {
            var package = await _context.GymPackages.FindAsync(id);
            if (package == null) return NotFound();

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null) return Unauthorized();

            var startDate = DateTime.UtcNow;
            var endDate = startDate.AddDays(package.DurationInDays);

            // Generate unique QR content
            string qrContent = $"{userId}|{package.Id}|{Guid.NewGuid()}";

            // Generate QR code image in memory
            using var qrGenerator = new QRCodeGenerator();
            var qrCodeData = qrGenerator.CreateQrCode(qrContent, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new QRCode(qrCodeData);
            using var bitmap = qrCode.GetGraphic(20);

            // Convert bitmap to byte array
            byte[] qrBytes;
            using (var ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                qrBytes = ms.ToArray();
            }

            // Save subscription with QR code in DB
            var subscription = new Models.Subscription
            {
                UserId = userId,
                GymPackageId = package.Id,
                StartDate = startDate,
                EndDate = endDate,
                QrCodeData = qrBytes
            };

            _context.Subscriptions.Add(subscription);
            await _context.SaveChangesAsync();

            // Pass QR code as base64 to view
            ViewBag.QrCodeBase64 = Convert.ToBase64String(qrBytes);

            return View("PaymentSuccess", package);
        }

        // GET: /GymPackages/PaymentCancel/{id}
        public IActionResult PaymentCancel(int id)
        {
            // Handle payment cancellation
            return View();
        }
    }
}
