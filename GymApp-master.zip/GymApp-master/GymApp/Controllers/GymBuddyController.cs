﻿using GymApp.Data;
using GymApp.Models;
using GymApp.Models.ViewModels;
using GymApp.Models.ViewModels.Gymbuddy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stripe;
using System.Security.Claims;

[Authorize]
public class GymBuddyController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<User> _userManager;

    public GymBuddyController(ApplicationDbContext context , UserManager<User> userManager)
    {
        _userManager = userManager;

        _context = context;
    }

    // Dashboard / Landing page
    public async Task<IActionResult> Index()
    {
        
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

        var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null) return Unauthorized();


        //dont allow admin
        if (await _userManager.IsInRoleAsync(user, "Admin"))
        {
            return RedirectToAction("Index", "Admin");
        }



        //All Relevent subs to User
        var subscriptions = await _context.Subscriptions
            .Include(s => s.GymPackage)
            .Where(s => s.UserId == userId)
            .ToListAsync();

        //Find If any freez was done
        var freezeRequests = await _context.MembershipFreezeRequests
            .Where(f => f.UserId == userId)
            .ToListAsync();

        var model = new UserDashboardViewModel
        {
            FreezeRequests = freezeRequests,
            FullName = user.FullName,
            Subscriptions = subscriptions
        };

        return View(model);
    }













    // Workout listing for a subscription
    public async Task<IActionResult> Workouts(int subscriptionId)
    {
        var subscription = await _context.Subscriptions
            .Include(s => s.GymPackage)
            .FirstOrDefaultAsync(s => s.Id == subscriptionId);

        if (subscription == null) return NotFound();

        var workouts = await _context.Workouts
            .Where(w => w.PackageId == subscription.GymPackageId)
            .ToListAsync();

        var model = new WorkoutListingViewModel
        {
            SubscriptionId = subscriptionId,
            PackageName = subscription.GymPackage.Name,
            Workouts = workouts.Select(w => new WorkoutViewModel
            {
                Id = w.Id,
                Title = w.Title,
                GifUrl = w.GifUrl,
                Instructions = w.Instructions,
                DurationInSeconds = w.DurationInSeconds
            }).ToList()
        };

        return View(model);
    }

    // Workout detail / timer page
    public async Task<IActionResult> WorkoutDetail(int subscriptionId)
    {
        var subscription = await _context.Subscriptions
            .Include(s => s.GymPackage)
            .FirstOrDefaultAsync(s => s.Id == subscriptionId);

        if (subscription == null) return NotFound();

        var workouts = await _context.Workouts
            .Where(w => w.PackageId == subscription.GymPackageId)
            .OrderBy(w => w.Id)
            .ToListAsync();

        // Map to WorkoutListingViewModel
        var model = new WorkoutListingViewModel
        {
            SubscriptionId = subscriptionId,
            PackageName = subscription.GymPackage.Name,
            Workouts = workouts.Select(w => new WorkoutViewModel
            {
                Id = w.Id,
                Title = w.Title,
                GifUrl = w.GifUrl,
                Instructions = w.Instructions,
                DurationInSeconds = w.DurationInSeconds
            }).ToList()
        };

        return View(model.Workouts);
    }





    [HttpGet]
    public IActionResult Treadmill()
    {
        var model = new TreadmillWorkoutViewModel();
        return View(model);
    }




    public IActionResult MyMembership()
    {
        var userId = _userManager.GetUserId(User);

        var request = _context.MembershipFreezeRequests
            .Where(r => r.UserId == userId)
            .OrderByDescending(r => r.RequestedOn)
            .FirstOrDefault();

        if (request == null)
        {
            request = new MembershipFreezeRequest
            {
                Status = "Not requested"
            };
        }

        return View(request);
    }











    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult RequestFreeze(int days)
    {
        var userId = _userManager.GetUserId(User);

        var request = new MembershipFreezeRequest
        {
            UserId = userId,
            RequestedOn = DateTime.Now,
            DaysRequested = days,
            Status = "Pending"
        };

        _context.MembershipFreezeRequests.Add(request);
        _context.SaveChanges();

        TempData["Message"] = "Your freeze request has been submitted and is pending admin approval.";
        return RedirectToAction("MyMembership");
    }



    [HttpPost]
    public async Task<IActionResult> ResumeMembership(int subscriptionId)
    {
        var userId = _userManager.GetUserId(User);

        var subscription = await _context.Subscriptions
            .Include(s => s.GymPackage)
            .FirstOrDefaultAsync(s => s.Id == subscriptionId && s.UserId == userId);

        if (subscription == null) return NotFound();

        var freeze = await _context.MembershipFreezeRequests
            .Where(f => f.UserId == userId && f.Status == "Approved")
            .OrderByDescending(f => f.RequestedOn)
            .FirstOrDefaultAsync();

        if (freeze == null)
        {
            TempData["Error"] = "No approved freeze request found.";
            return RedirectToAction("Index");
        }

        subscription.EndDate = subscription.EndDate.AddDays(freeze.DaysRequested);


        freeze.Status = "Resumed";

        await _context.SaveChangesAsync();

        TempData["Message"] = "Your membership has been resumed!";
        return RedirectToAction("Index");
    }

    [HttpPost]
    public async Task<IActionResult> RenewMembership(int subscriptionId)
    {
        var userId = _userManager.GetUserId(User);

        var subscription = await _context.Subscriptions
            .Include(s => s.GymPackage)
            .FirstOrDefaultAsync(s => s.Id == subscriptionId && s.UserId == userId);

        if (subscription == null) return NotFound();

        // Extend the subscription by the package duration
        subscription.StartDate = DateTime.UtcNow;
        subscription.EndDate = DateTime.UtcNow.AddDays(subscription.GymPackage.DurationInDays);

        await _context.SaveChangesAsync();

        TempData["Message"] = "Your membership has been renewed!";
        return RedirectToAction("Index");
    }

}