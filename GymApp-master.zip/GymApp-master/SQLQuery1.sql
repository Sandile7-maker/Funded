DELETE FROM Subscriptions;

-- Optional: reset identity/auto-increment
DBCC CHECKIDENT ('Subscriptions', RESEED, 0);

-- Verify
SELECT * FROM Subscriptions;
SELECT * FROM AspNetUsers;